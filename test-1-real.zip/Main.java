void pyramid()

system.out.orintln();
system.out.println"*");
for(i=1;i<=4;i++)
{
    for(k=1;k<=4-i;k++)
    {
        system.out.println(" ")
    ;
    }
    for(j=1;j<=2*i-2;j++)
    {system.out.print("*");
    }
    system.out.println();
}
}